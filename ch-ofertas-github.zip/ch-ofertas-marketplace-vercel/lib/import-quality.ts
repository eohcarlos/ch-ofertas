import { attributes, gallery, type Product } from "./catalog";
import { variants } from "./commerce";

export const GENERIC_DESCRIPTION = "Confira as características e as condições deste produto no anúncio do Mercado Livre.";
export function importQuality(product: Partial<Product>) {
  const options = variants(product.variants_json), photos = new Set([product.image_url, ...gallery(product.gallery_json || "[]")].filter(Boolean)).size;
  const specs = attributes(product.specifications_json || "[]").length;
  const checks = [
    { label: "Nome do produto", found: !!product.title },
    { label: "Foto principal", found: photos > 0 },
    { label: "Preço", found: !!product.price_cents },
    { label: "Descrição", found: !!product.description && product.description !== GENERIC_DESCRIPTION },
    { label: "Ficha técnica", found: specs > 0 },
    { label: "Disponibilidade", found: !!product.availability && product.availability !== "unknown" },
    ...(options.length ? [{ label: "Preços das opções", found: options.every(v => v.price_cents != null || v.availability === "out_of_stock") }] : []),
  ];
  const missing = checks.filter(c => !c.found).map(c => c.label);
  return { checks, missing, photos, specifications: specs, options: options.length, partial: missing.length > 0 };
}
