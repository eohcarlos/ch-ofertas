export type FirecrawlUsage = {
  remainingCredits: number;
  planCredits: number | null;
  billingPeriodStart: string | null;
  billingPeriodEnd: string | null;
  checkedAt: string;
};
export type FirecrawlSettings = { hasKey: boolean; mode: string };
export type FirecrawlConnection = { url: string; expiresAt: number };

export class FirecrawlError extends Error {
  constructor(message: string, public status = 400, public retryAfter: number | null = null) { super(message); }
}

export function retrySeconds(header: string | null) {
  if (!header) return null;
  const seconds = /^\d+$/.test(header) ? Number(header) : Math.ceil((Date.parse(header) - Date.now()) / 1000);
  return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : null;
}

export async function fetchFirecrawlUsage(key: string): Promise<FirecrawlUsage> {
  let response: Response;
  try {
    response = await fetch("https://api.firecrawl.dev/v2/team/credit-usage", {
      headers: { Authorization: "Bearer " + key, Accept: "application/json" },
      // Do not forward the account key on redirects. Workers require manual mode.
      cache: "no-store", redirect: "manual", signal: AbortSignal.timeout(15000),
    });
  } catch (error) {
    console.error("Firecrawl credit request failed", {
      name: error instanceof Error ? error.name : "Error",
      message: (error instanceof Error ? error.message : "Unknown fetch error").replaceAll(key, "[redacted]").slice(0, 400),
    });
    throw new FirecrawlError("Não foi possível consultar o saldo do Firecrawl agora. Tente novamente em instantes.", 502);
  }
  if (response.status === 401 || response.status === 403) throw new FirecrawlError("A chave não foi autorizada pelo Firecrawl. Confira a chave e a permissão para consultar créditos.", response.status);
  if (response.status === 429) throw new FirecrawlError("A consulta de saldo atingiu o limite do Firecrawl. Aguarde antes de atualizar novamente.", 429, retrySeconds(response.headers.get("retry-after")));
  let result: { success?: boolean; data?: Record<string, unknown> };
  try { result = await response.json(); } catch { throw new FirecrawlError("O Firecrawl não retornou um saldo válido. O saldo anterior foi mantido.", 502); }
  const data = result.data;
  if (!response.ok || !result.success || !data || typeof data.remainingCredits !== "number" || !Number.isFinite(data.remainingCredits)) throw new FirecrawlError("O Firecrawl não retornou um saldo válido. Tente novamente mais tarde.", 502);
  const date = (v: unknown) => typeof v === "string" && Number.isFinite(Date.parse(v)) ? new Date(v).toISOString() : null;
  return {
    remainingCredits: data.remainingCredits,
    planCredits: typeof data.planCredits === "number" && Number.isFinite(data.planCredits) ? data.planCredits : null,
    billingPeriodStart: date(data.billingPeriodStart), billingPeriodEnd: date(data.billingPeriodEnd), checkedAt: new Date().toISOString(),
  };
}
