import type { Product, ProductAttribute } from "./catalog";
import { isMercadoUrl, validImage } from "./product-urls";

export const DETAIL_FIELDS = {
  model: "Modelo", voltage: "Voltagem", color: "Cor", material: "Material",
  capacity: "Capacidade", power: "Potência", dimensions: "Dimensões", weight: "Peso",
  condition: "Condição", warranty: "Garantia", shipping: "Entrega e frete", seller: "Vendedor",
  sku: "SKU / referência", included: "Itens incluídos", compatibility: "Compatibilidade",
} as const;
export type ProductDetails = Partial<Record<keyof typeof DETAIL_FIELDS, string>>;
export type Availability = "unknown" | "in_stock" | "out_of_stock";
export type ProductVariant = {
  id: string; attributes: ProductAttribute[]; sku: string;
  price_cents: number | null; original_price_cents: number | null; price_note: string;
  image_url: string; affiliate_url: string; source_url: string;
  availability: Availability; stock_quantity: number | null; stock_text: string; quantity: number | null;
  offer_starts_at: string; offer_ends_at: string; offer_source: string; checked_at: string;
};
const clean = (v: unknown, max = 300) => typeof v === "string" ? v.trim().slice(0, max) : "";
const object = (v: unknown): Record<string, unknown> => v && typeof v === "object" && !Array.isArray(v) ? v as Record<string, unknown> : {};
function parse(value: unknown, fallback: unknown) { try { return typeof value === "string" ? JSON.parse(value) : value ?? fallback; } catch { return fallback; } }
export function productDetails(value?: string): ProductDetails {
  const data = object(parse(value, {}));
  return Object.fromEntries(Object.keys(DETAIL_FIELDS).map(k => [k, clean(data[k], 500)]).filter(([,v]) => v));
}
export function dateValue(value: unknown) {
  if (!value) return "";
  if (typeof value !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d(?:\.\d{1,3})?)?(?:Z|[+-]\d\d:\d\d)$/.test(value) || !Number.isFinite(Date.parse(value))) throw new Error("Informe uma data e hora válidas para a oferta.");
  return new Date(value).toISOString();
}
export function offerDates(start: unknown, end: unknown) {
  const offer_starts_at = dateValue(start), offer_ends_at = dateValue(end);
  if (offer_starts_at && !offer_ends_at) throw new Error("Informe quando a oferta termina.");
  if (offer_starts_at && Date.parse(offer_starts_at) >= Date.parse(offer_ends_at)) throw new Error("O fim da oferta precisa ser depois do início.");
  return { offer_starts_at, offer_ends_at };
}
export function variantKey(v: Pick<ProductVariant, "attributes">) {
  return v.attributes.map(a => [a.name.trim().toLocaleLowerCase("pt-BR"), a.value.trim().toLocaleLowerCase("pt-BR")].join(":")).sort().join("|");
}
export function variantLabel(v: Pick<ProductVariant, "attributes">) { return v.attributes.map(a => a.value).join(" · "); }
export function normalizeVariants(value: unknown): ProductVariant[] {
  const parsed = parse(value, []);
  if (!Array.isArray(parsed) || parsed.length > 60) throw new Error("Cadastre até 60 combinações por produto.");
  const keys = new Set<string>(), ids = new Set<string>();
  const number = (v: unknown, max: number, zero = false): number | null => {
    if (v == null || v === "") return null;
    if (typeof v !== "number" || !Number.isInteger(v) || v < (zero ? 0 : 1) || v > max) throw new Error("Confira o preço, estoque e unidades de cada variação.");
    return v;
  };
  return parsed.map((raw, index) => {
    const v = object(raw), attrs = Array.isArray(v.attributes) ? v.attributes : [];
    if (!attrs.length || attrs.length > 5) throw new Error("Cada variação precisa ter de 1 a 5 características, como voltagem e cor.");
    const attributes = attrs.map(raw => { const a = object(raw); return { name: clean(a.name, 50), value: clean(a.value, 100) }; });
    if (attributes.some(a => !a.name || !a.value) || new Set(attributes.map(a => a.name.toLowerCase())).size !== attributes.length) throw new Error("Preencha o nome e o valor das características sem repetir campos na mesma opção.");
    const key = variantKey({attributes});
    if (keys.has(key)) throw new Error("Existem variações repetidas. Cada combinação deve ser única.");
    keys.add(key);
    const id = clean(v.id, 100) || "option-" + (index + 1);
    if (ids.has(id)) throw new Error("Identificador de variação repetido.");
    ids.add(id);
    const image_url = clean(v.image_url, 2048), affiliate_url = clean(v.affiliate_url, 2048), source_url = clean(v.source_url, 2048);
    if (image_url && !validImage(image_url)) throw new Error("Confira a imagem da variação.");
    if ((affiliate_url && !isMercadoUrl(affiliate_url)) || (source_url && !isMercadoUrl(source_url))) throw new Error("Os links das variações precisam ser do Mercado Livre.");
    const price_cents = number(v.price_cents, 100_000_000), original = number(v.original_price_cents, 100_000_000);
    const stock_quantity = number(v.stock_quantity, 1_000_000, true);
    return { id, attributes, sku: clean(v.sku, 100), price_cents, original_price_cents: price_cents && original && original > price_cents ? original : null,
      price_note: clean(v.price_note), image_url, affiliate_url, source_url,
      availability: stock_quantity === 0 ? "out_of_stock" : ["in_stock", "out_of_stock"].includes(String(v.availability)) ? v.availability as Availability : "unknown",
      stock_quantity, stock_text: clean(v.stock_text), quantity: number(v.quantity, 100000),
      ...offerDates(v.offer_starts_at, v.offer_ends_at), offer_source: v.offer_source === "firecrawl" ? "firecrawl" : "manual", checked_at: dateValue(v.checked_at),
    };
  });
}
export function variants(value?: string): ProductVariant[] { try { return normalizeVariants(value); } catch { return []; } }
export function promotionState(p: { offer_starts_at?: string; offer_ends_at?: string }, now = Date.now()) {
  const end = Date.parse(p.offer_ends_at || "");
  if (!Number.isFinite(end)) return "none";
  if (end <= now) return "expired";
  if (p.offer_starts_at && Date.parse(p.offer_starts_at) > now) return "scheduled";
  return "active";
}
export function displayPrice(p: Pick<Product, "price_cents"> & { offer_starts_at?: string; offer_ends_at?: string }, now = Date.now()) {
  const state = promotionState(p, now);
  return state === "expired" || state === "scheduled" ? null : p.price_cents;
}
export function variantProduct(product: Product, variant: ProductVariant): Product {
  return { ...product, price_cents: variant.price_cents, original_price_cents: variant.original_price_cents, price_note: variant.price_note,
    image_url: variant.image_url || product.image_url, affiliate_url: variant.affiliate_url || product.affiliate_url,
    availability: variant.availability, stock_text: variant.stock_text || (variant.stock_quantity != null ? variant.stock_quantity + " disponível(is)" : ""),
    quantity: variant.quantity, size: variant.attributes.find(a=>/^(?:tamanho|medidas|dimensões)$/i.test(a.name))?.value || product.size, offer_starts_at: variant.offer_starts_at, offer_ends_at: variant.offer_ends_at,
    offer_source: variant.offer_source, price_checked_at: variant.checked_at, last_synced_at: variant.checked_at };
}
export function lowestPrice(product: Product, now = Date.now()) {
  const rows = variants(product.variants_json);
  return rows.length ? Math.min(...rows.filter(v => v.availability !== "out_of_stock").map(v => displayPrice(v, now) ?? Infinity)) : displayPrice(product, now) ?? Infinity;
}
export function mergeVariants(previous: string | undefined, incoming: string | undefined) {
  const old = variants(previous), fresh = variants(incoming), known = new Set(fresh.map(variantKey));
  return JSON.stringify([...fresh.map(v => {
    const saved = old.find(o => variantKey(o) === variantKey(v));
    return saved ? { ...v, id: saved.id, affiliate_url: saved.affiliate_url, image_url: v.image_url || saved.image_url,
      ...(v.price_cents == null ? {price_cents:saved.price_cents,original_price_cents:saved.original_price_cents,price_note:saved.price_note,checked_at:saved.checked_at} : {}),
      ...(saved.offer_source === "manual" && !v.offer_ends_at ? {offer_starts_at:saved.offer_starts_at,offer_ends_at:saved.offer_ends_at,offer_source:"manual"} : {}) } : v;
  }), ...old.filter(v => !known.has(variantKey(v)))].slice(0, 60));
}
export function emptyVariant(): ProductVariant {
  return {id:crypto.randomUUID(),attributes:[{name:"Voltagem",value:""}],sku:"",price_cents:null,original_price_cents:null,price_note:"",image_url:"",affiliate_url:"",source_url:"",availability:"unknown",stock_quantity:null,stock_text:"",quantity:null,offer_starts_at:"",offer_ends_at:"",offer_source:"manual",checked_at:""};
}

// One-time upgrade of already verified descriptive fields. A multi-value option
// is never assigned the selected product's price or expanded into invented pairs.
export function legacyCommerce(product: Product) {
  const parsed=parse(product.specifications_json,[]),options=parse(product.options_json,[]);
  const specs=(Array.isArray(parsed)?parsed:[]).map(raw=>{const a=object(raw);return {name:clean(a.name,80),value:clean(a.value,500)};});
  const details:ProductDetails={...productDetails(product.details_json)};
  for(const [key,label] of Object.entries(DETAIL_FIELDS)) {
    const found=specs.find(s=>s.name.toLocaleLowerCase("pt-BR")===label.toLocaleLowerCase("pt-BR"));
    if(found?.value && !details[key as keyof ProductDetails])details[key as keyof ProductDetails]=found.value;
  }
  const attributes=(Array.isArray(options)?options:[]).map(raw=>{const a=object(raw);return {name:clean(a.name,50),value:clean(a.value,100)};});
  const concrete=attributes.length>0&&attributes.length<=5&&attributes.every(a=>a.name&&a.value&&!/[,;|]|\bou\b/i.test(a.value));
  let rows=variants(product.variants_json);
  if(!rows.length && concrete)rows=normalizeVariants([{id:"existing-option",attributes,price_cents:product.price_cents,original_price_cents:product.original_price_cents,price_note:product.price_note,image_url:product.image_url,availability:product.availability,stock_text:product.stock_text,quantity:product.quantity,source_url:product.source_url,checked_at:product.price_checked_at||product.last_synced_at}]);
  return {variants_json:JSON.stringify(rows),details_json:JSON.stringify(details)};
}
