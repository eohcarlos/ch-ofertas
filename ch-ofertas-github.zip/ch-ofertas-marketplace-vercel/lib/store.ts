import "server-only";
import { cache } from "react";
import { headers } from "next/headers";
import type { Product } from "@/lib/catalog";
import { adminCookie, backendFetch } from "./backend";

export const adminCatalog = cache(async (): Promise<Product[] | null> => {
  const cookie = adminCookie(await headers());
  if (!cookie) return null;
  const response = await backendFetch("/api/admin", { headers: { cookie } });
  if (response.status === 401) return null;
  if (!response.ok) throw new Error("Painel temporariamente indisponível.");
  const data = await response.json();
  if (!Array.isArray(data.products)) throw new Error("Resposta inválida do catálogo.");
  return data.products;
});

export async function readProducts(): Promise<Product[]> {
  const response = await backendFetch("/api/catalog");
  if (!response.ok) throw new Error("Catálogo temporariamente indisponível.");
  const data = await response.json();
  if (!Array.isArray(data.products)) throw new Error("Resposta inválida do catálogo.");
  return data.products;
}
