export function isMercadoUrl(value: string) {
  try {
    const u = new URL(value), h = u.hostname.toLowerCase();
    return u.protocol === "https:" && !u.username && !u.password && !u.port && value.length <= 2048 &&
      ["meli.la", "mercadolivre.com.br", "mercadolivre.com"].some(d => h === d || h.endsWith("." + d));
  } catch { return false; }
}
export function validImage(value: string) {
  if (/^\/products\/[A-Za-z0-9]+\.webp$/.test(value)) return true;
  if (/^\/api\/images\/[a-f0-9-]+\.(png|jpg|webp)$/.test(value)) return true;
  try {
    const u = new URL(value);
    return u.protocol === "https:" && !u.username && !u.password && !u.port && u.hostname.includes(".") && !/^[\d.:\[\]]+$/.test(u.hostname) && !u.hostname.endsWith(".local") && value.length <= 2048;
  } catch { return false; }
}
export function imageIdentity(value: string) {
  try {
    const url = new URL(value);
    if (/(?:^|\.)mlstatic\.com$/.test(url.hostname)) return url.pathname.match(/(\d{6}-(?:ML[A-Z]|CBT)\d+_\d{6})/i)?.[1] || value;
  } catch {}
  return value;
}
export function uniqueImages(values: string[], limit = 16) {
  const seen = new Set<string>();
  return values.filter(value => {
    const key = imageIdentity(value);
    if (!validImage(value) || seen.has(key)) return false;
    seen.add(key); return true;
  }).slice(0, limit);
}
