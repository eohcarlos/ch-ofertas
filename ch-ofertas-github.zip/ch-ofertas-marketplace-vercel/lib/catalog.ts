import { normalizeVariants, productDetails, offerDates, dateValue, promotionState } from "./commerce";
import { isMercadoUrl, validImage, uniqueImages } from "./product-urls";
export { isMercadoUrl, validImage } from "./product-urls";
export const CATEGORIES = ["Tecnologia", "Casa e cozinha", "Escritório e móveis", "Moda e acessórios", "Beleza e cuidados", "Ferramentas", "Automotivo", "Esporte e lazer", "Outros"];
export type Product = {
  id: string; title: string; description: string; category: string;
  affiliate_url: string; source_url: string; image_url: string;
  status: "draft" | "active"; featured: number; position: number; created_at: string; updated_at: string;
  price_cents: number | null; original_price_cents: number | null; price_note: string;
  brand: string; size: string; quantity: number | null; stock_text: string;
  availability: "unknown" | "in_stock" | "out_of_stock";
  options_json: string; specifications_json: string; gallery_json: string;
  last_synced_at: string; sync_error: string;
  variants_json?: string; details_json?: string; offer_starts_at?: string; offer_ends_at?: string; offer_source?: string; price_checked_at?: string;
};
export type ProductAttribute = { name: string; value: string };
export function attributes(value: string): ProductAttribute[] {
  try { const data = JSON.parse(value); return Array.isArray(data) ? data.filter(x => x && typeof x.name === "string" && typeof x.value === "string").slice(0,80) : []; } catch { return []; }
}
export function gallery(value: string): string[] {
  try { const data = JSON.parse(value); return Array.isArray(data) ? uniqueImages(data.filter(x => typeof x === "string")) : []; } catch { return []; }
}
export const money = (cents: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
export function discount(product: Product, now = Date.now()) {
  const promotion = promotionState(product, now), checked = Date.parse(product.price_checked_at || product.last_synced_at);
  if (promotion === "expired" || promotion === "scheduled") return 0;
  if (product.availability === "out_of_stock" || !product.price_cents || !product.original_price_cents || product.original_price_cents <= product.price_cents || !Number.isFinite(checked) || now - checked > 86400000) return 0;
  return Math.round((1 - product.price_cents / product.original_price_cents) * 100);
}
export function productInput(input: Record<string, unknown>) {
  const str = (key: string, max: number) => typeof input[key] === "string" ? (input[key] as string).trim().slice(0, max) : "";
  const p = { title: str("title", 200), description: str("description", 6000), category: str("category", 60) || "Outros",
    affiliate_url: str("affiliate_url", 2048), source_url: str("source_url", 2048), image_url: str("image_url", 2048),
    status: input.status === "active" ? "active" : "draft", featured: input.featured ? 1 : 0 };
  const number = (key: string, max: number) => {
    const v = input[key]; if (v == null || v === "") return null;
    if (typeof v !== "number" || !Number.isInteger(v) || v < 1 || v > max) throw new Error("Confira os valores de preço e quantidade.");
    return v;
  };
  const price_cents = number("price_cents", 100_000_000), original_price_cents = number("original_price_cents", 100_000_000);
  const list = (key: string) => JSON.stringify(attributes(str(key, 50000)).map(x => ({ name: x.name.trim().slice(0,80), value: x.value.trim().slice(0,500) })).filter(x => x.name && x.value));
  if (!isMercadoUrl(p.affiliate_url)) throw new Error("Use um link HTTPS de afiliado do Mercado Livre.");
  if (p.source_url && !isMercadoUrl(p.source_url)) throw new Error("O link completo precisa ser do Mercado Livre.");
  if (!CATEGORIES.includes(p.category)) throw new Error("Escolha uma categoria válida.");
  if (p.image_url && !validImage(p.image_url)) throw new Error("Use uma imagem HTTPS ou envie uma foto.");
  if (p.status === "active" && (p.title.length < 3 || !p.image_url)) throw new Error("Adicione o nome e a imagem do produto antes de publicar.");
  return { ...p, price_cents, original_price_cents: original_price_cents && price_cents && original_price_cents > price_cents ? original_price_cents : null,
    price_note: str("price_note", 300), brand: str("brand", 100), size: str("size", 200), quantity: number("quantity", 100000), stock_text: str("stock_text", 300),
    availability: ["in_stock", "out_of_stock"].includes(String(input.availability)) ? String(input.availability) : "unknown",
    variants_json: JSON.stringify(normalizeVariants(input.variants_json)), details_json: JSON.stringify(productDetails(str("details_json", 15000))),
    ...offerDates(input.offer_starts_at, input.offer_ends_at), offer_source: input.offer_source === "firecrawl" ? "firecrawl" : "manual", price_checked_at: dateValue(input.price_checked_at),
    options_json: list("options_json"), specifications_json: list("specifications_json"), gallery_json: JSON.stringify(gallery(str("gallery_json", 34000))),
  };
}
