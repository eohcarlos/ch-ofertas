import "server-only";

export const BACKEND_ORIGIN = "https://ch-ofertas.iamcarlostrader-2023.chatgpt.site";
const ADMIN_COOKIE = "__Host-ch-admin";

// Forward only our own session cookie, never Vercel or other browser cookies.
export function adminCookie(headers: Headers) {
  const token = headers.get("cookie")?.split(";").map(part => part.trim()).find(part => part.startsWith(ADMIN_COOKIE + "="))?.slice(ADMIN_COOKIE.length + 1);
  return token && /^[a-f0-9]{64}$/.test(token) ? `${ADMIN_COOKIE}=${token}` : "";
}

export async function backendFetch(path: string, init: RequestInit = {}) {
  if (!path.startsWith("/api/") || path.includes("..") || path.includes("\\")) throw new Error("Rota inválida.");
  return fetch(BACKEND_ORIGIN + path, { ...init, cache: "no-store", redirect: "error", signal: AbortSignal.timeout(270_000) });
}
