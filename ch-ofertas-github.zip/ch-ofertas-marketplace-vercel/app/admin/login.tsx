"use client";
import { useState } from "react";
import { LockKeyhole, ArrowRight, LoaderCircle, Eye, EyeOff } from "lucide-react";
import { Brand } from "../brand";
export default function AdminLogin() {
  const [password, setPassword] = useState(""), [visible, setVisible] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Não foi possível entrar.");
      window.location.replace("/admin");
    } catch (e) { setError((e as Error).message); setBusy(false); }
  }
  return <main className="admin-login"><section className="login-card"><Brand/><span className="login-lock"><LockKeyhole size={26}/></span><span className="eyebrow">ACESSO RESTRITO</span><h1>Seu espaço de<br/>boas escolhas.</h1><p>Digite sua senha para gerenciar a vitrine.</p><form onSubmit={submit}><label htmlFor="admin-password">Senha de acesso</label><div className="password-input"><input id="admin-password" name="password" type={visible ? "text" : "password"} autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required maxLength={200}/><button type="button" onClick={() => setVisible(!visible)} aria-label={visible ? "Ocultar senha" : "Mostrar senha"}>{visible ? <EyeOff size={19}/> : <Eye size={19}/>}</button></div>{error && <p className="form-error" role="alert">{error}</p>}<button className="button yellow" disabled={busy}>{busy ? <LoaderCircle className="spin" size={18}/> : <ArrowRight size={18}/>} {busy ? "Entrando..." : "Entrar no painel"}</button></form><a href="/" className="login-back">Voltar à loja</a></section><span className="login-caption">CH Ofertas · Administração</span></main>;
}
