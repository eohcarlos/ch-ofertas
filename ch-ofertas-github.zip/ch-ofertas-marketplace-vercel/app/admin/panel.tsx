"use client";
import { useEffect, useRef, useState } from "react";
import { Plus, Link2, Package, Eye, Pencil, Trash2, ImagePlus, LoaderCircle, Search, Check, ExternalLink, Sparkles, Info, X, Flame, RefreshCw, LogOut, Square, CheckCircle2, AlertCircle } from "lucide-react";
import { Brand } from "../brand";
import { CATEGORIES, money, discount, attributes, type Product } from "@/lib/catalog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription } from "@/components/ui/empty";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";

import { api, ApiError } from "./api";
import FirecrawlPanel from "./firecrawl-panel";
import FirecrawlAccount from "./firecrawl-account";
import ProductOptionsEditor, { ExtraProductFields, OfferFields } from "./product-options-editor";
import { variants, mergeVariants, productDetails } from "@/lib/commerce";

export default function AdminPanel({ initialProducts }: { initialProducts: Product[] }) {
  const [products, setProducts] = useState(initialProducts), [query, setQuery] = useState(""), [tab, setTab] = useState("all");
  const [edit, setEdit] = useState<Product | null>(null), [deleting, setDeleting] = useState<Product | null>(null), [saving, setSaving] = useState(false), [uploading, setUploading] = useState(false), [searching, setSearching] = useState(false), [error, setError] = useState("");
  const [optionText,setOptionText] = useState(""), [specText,setSpecText] = useState("");
  const encodeAttributes = (value:string) => JSON.stringify(value.split("\n").map(row=>({name:row.split(":")[0].trim(),value:row.split(":").slice(1).join(":").trim()})).filter(x=>x.name && x.value));
  const [section,setSection] = useState("products"), [syncing,setSyncing] = useState(false), [importBusy,setImportBusy] = useState(false), [currentSync,setCurrentSync] = useState("");
  const [syncResults,setSyncResults] = useState<{ id:string; title:string; ok:boolean; message:string }[]>([]), [syncTotal,setSyncTotal] = useState(0);
  const [stopRequested,setStopRequested] = useState(false);
  const [creditsRevision, setCreditsRevision] = useState(0), [firecrawlConfigured, setFirecrawlConfigured] = useState(false);
  const creditsChanged = () => setCreditsRevision(value => value + 1);
  const stopSync = useRef(false);
  const progressPanel = useRef<HTMLElement | null>(null);
  useEffect(() => { if (syncing) progressPanel.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, [syncing]);
  const acceptProduct = (p: Product) => setProducts(items => items.some(x=>x.id===p.id) ? items.map(x=>x.id===p.id?p:x) : [p,...items]);
  async function updateProducts(items: Product[]) {
    if (syncing || importBusy || !items.length) return;
    setSyncing(true); setSyncResults([]); setSyncTotal(items.length); setStopRequested(false); stopSync.current=false;
    let completed=0;
    try {
      for (const product of items) {
        if (stopSync.current) break;
        setCurrentSync(product.title || product.affiliate_url);
        try { const r=await api("/firecrawl/refresh/"+product.id,"POST",{});acceptProduct(r.product);completed++;setSyncResults(rows=>[...rows,{id:product.id,title:r.product.title,ok:true,message:r.warnings?.join(" ") || "Informações atualizadas."}]); }
        catch(e) { const err=e as Error;setSyncResults(rows=>[...rows,{id:product.id,title:product.title || product.affiliate_url,ok:false,message:err.message}]);if(e instanceof ApiError && [401,402,403,429].includes(e.status)) {stopSync.current=true;break;} } finally { creditsChanged(); }
      }
      setCurrentSync("");
      await refresh();
      if (completed) toast.success(`${completed} produto(s) atualizado(s).`);
      else toast.info("Nenhum produto foi atualizado. Confira o resultado das consultas.");
    } catch(e) {toast.error((e as Error).message);} finally {setSyncing(false);setCurrentSync("");}
  }
  async function signOut() { try {await api("/logout","POST",{});window.location.replace("/admin");} catch(e) {toast.error((e as Error).message);} }
  const published = products.filter(p => p.status === "active").length;
  const filtered = products.filter(p => (tab === "all" || (tab === "active" ? p.status === "active" : p.status === "draft")) && (p.title + p.affiliate_url).toLowerCase().includes(query.toLowerCase()));
  const refresh = async () => { const data = await api(""); setProducts(data.products); };
  const importLinks = async (values: string[]) => {
    const result = await api("/import", "POST", { links: values }); setProducts(result.products); return result;
  };
  useEffect(() => {
    const context = (document as unknown as { modelContext?: { registerTool: (tool: unknown, options: unknown) => unknown } }).modelContext;
    if (!context?.registerTool) return;
    const controller = new AbortController();
    try { Promise.resolve(context.registerTool({ name: "add_affiliate_links_as_drafts", title: "Adicionar links à vitrine", description: "Salva links do Mercado Livre como rascunhos. Não publica produtos nem realiza compras.", inputSchema: { type: "object", properties: { links: { type: "array", minItems: 1, maxItems: 30, items: { type: "string" } } }, required: ["links"], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: true }, execute: async (input: { links: string[] }) => { if (!input || !Array.isArray(input.links) || input.links.some(l => typeof l !== "string")) throw new Error("Informe uma lista de links."); const r = await importLinks(input.links); return { savedAsDrafts: r.added, total: r.products.length }; } }, { signal: controller.signal })).catch(() => {}); } catch {}
    return () => controller.abort();
  }, []);
  function openEditor(p: Product) { setError(""); setEdit({ ...p }); setOptionText(attributes(p.options_json).map(x=>x.name+": "+x.value).join("\n")); setSpecText(attributes(p.specifications_json).map(x=>x.name+": "+x.value).join("\n")); }
  async function saveProduct(e: React.FormEvent) {
    e.preventDefault(); if (!edit) return; setSaving(true); setError("");
    try { await api("/products/" + edit.id, "PATCH", {...edit,options_json:encodeAttributes(optionText),specifications_json:encodeAttributes(specText)}); await refresh(); setEdit(null); toast.success(edit.status === "active" ? "Produto publicado na vitrine." : "Rascunho salvo."); }
    catch (e) { setError((e as Error).message); } finally { setSaving(false); }
  }
  async function lookup() {
    if (!edit) return; setSearching(true); setError("");
    try {
      const data = await api("/metadata/" + edit.id, "POST", { url: edit.affiliate_url });
      setEdit(p => p ? { ...p, ...data.metadata, variants_json: mergeVariants(p.variants_json, data.metadata.variants_json), details_json: JSON.stringify({...productDetails(p.details_json),...productDetails(data.metadata.details_json)}) } : p); setOptionText(attributes(data.metadata.options_json || "[]").map(x=>x.name+": "+x.value).join("\n"));setSpecText(attributes(data.metadata.specifications_json || "[]").map(x=>x.name+": "+x.value).join("\n"));
      toast.success("Dados encontrados. Revise antes de salvar e publicar.");
    } catch (e) { setError((e as Error).message); } finally { setSearching(false); creditsChanged(); }
  }
  async function upload(file?: File) {
    if (!file) return; setUploading(true); setError("");
    try { const form = new FormData(); form.set("image", file); const result = await api("/upload", "POST", form); setEdit(p => p ? { ...p, image_url: result.image_url } : p); }
    catch (e) { setError((e as Error).message); } finally { setUploading(false); }
  }
  async function remove() {
    if (!deleting) return;
    try { await api("/products/" + deleting.id, "DELETE"); setProducts(p => p.filter(x => x.id !== deleting.id)); setDeleting(null); toast.success("Produto excluído."); } catch (e) { toast.error((e as Error).message); }
  }
  const busy = saving || searching || uploading;
  const syncCount = syncResults.length, syncFailed = syncResults.filter(r=>!r.ok).length, syncSucceeded = syncCount - syncFailed;
  const syncRemaining = Math.max(0,syncTotal-syncCount);
  const syncPercent = syncTotal ? Math.min(syncing ? 99 : 100,Math.floor(syncCount/syncTotal*100)) : 0;
  const syncComplete = !syncing && syncTotal > 0 && syncRemaining === 0;
  const syncTitle = syncing ? currentSync ? stopRequested ? "Finalizando o produto atual" : "Atualizando seus produtos" : "Finalizando atualização" : syncComplete ? syncFailed ? "Atualização concluída com pendências" : "Atualização concluída" : "Atualização interrompida";
  return <div className="admin-app"><Toaster richColors position="top-center"/><header className="admin-header"><div className="container header-inner"><Brand/><span className="admin-label">PAINEL DA LOJA</span><div className="admin-header-actions"><a href="/" className="button light small" target="_blank" rel="noopener"><Eye size={17}/> Ver vitrine</a><button onClick={()=>void signOut()} className="button light small" disabled={syncing || importBusy}><LogOut size={16}/> Sair</button></div></div></header>
    <main className="container admin-main"><div className="admin-title"><div><span className="eyebrow">SEU ESPAÇO DE CURADORIA</span><h1>Sua vitrine<span>.</span></h1><p>Seus produtos organizados. Seus próximos achados a um link de distância.</p></div><span className="owner-pill"><ShieldIcon/> Acesso restrito</span></div>
      <div className="admin-stats"><div><span>Links cadastrados</span><strong>{products.length.toString().padStart(2, "0")}</strong><Link2 size={25}/></div><div><span>Na vitrine</span><strong>{published.toString().padStart(2, "0")}</strong><Eye size={25}/></div><div className="stat-yellow"><span>Aguardando publicação</span><strong>{(products.length - published).toString().padStart(2, "0")}</strong><Package size={25}/></div></div>
      <div className="admin-section-bar"><div className="admin-section-tabs" role="tablist" aria-label="Seções do painel"><button role="tab" aria-selected={section === "products"} onClick={()=>setSection("products")} className={section === "products" ? "active" : ""}><Package size={18}/> Produtos</button><button role="tab" aria-selected={section === "firecrawl"} onClick={()=>setSection("firecrawl")} className={section === "firecrawl" ? "active" : ""}><Flame size={18}/> Firecrawl</button></div><button className="button dark small" onClick={()=>void updateProducts(products)} disabled={syncing || importBusy || !products.length}>{syncing ? <LoaderCircle size={17} className="spin"/> : <RefreshCw size={17}/>} {syncing ? "Atualizando..." : "Atualizar todos os produtos"}</button></div>
      <FirecrawlAccount revision={creditsRevision} busy={syncing || importBusy || searching} onConfigured={setFirecrawlConfigured}/>
      {(syncing || syncResults.length > 0) && <section ref={progressPanel} className={"sync-progress " + (syncing ? "is-running" : syncComplete && !syncFailed ? "is-complete" : "has-pending")} aria-labelledby="sync-title">
        <div className="sync-progress-top"><div className="sync-heading" role="status" aria-live="polite"><strong id="sync-title">{syncing ? <LoaderCircle size={20} className="spin"/> : syncComplete && !syncFailed ? <CheckCircle2 size={20}/> : <AlertCircle size={20}/>} {syncTitle}</strong><p>{syncing ? currentSync ? `Consultando: ${currentSync}` : "Conferindo os resultados no painel..." : `${syncSucceeded} atualizado(s) · ${syncFailed} com erro${syncRemaining ? ` · ${syncRemaining} ainda não consultado(s)` : ""}`}</p></div><span className="sync-percentage" aria-hidden="true">{syncPercent}<small>%</small></span></div>
        <div className="sync-meter" role="progressbar" aria-label="Progresso da atualização dos produtos" aria-valuenow={syncPercent} aria-valuemin={0} aria-valuemax={100} aria-valuetext={`${syncPercent}% — ${syncCount} de ${syncTotal} produtos consultados`}><div className="sync-meter-fill" style={{ width: `${syncPercent}%` }}/></div>
        <div className="sync-progress-meta"><span>{syncCount} de {syncTotal} {syncTotal === 1 ? "produto consultado" : "produtos consultados"}</span><span>{syncing ? "Deixe esta aba aberta até terminar." : syncComplete ? "Consulta finalizada." : "Você pode iniciar uma nova atualização."}</span></div>
        {syncing && <div className="sync-controls"><span>A porcentagem avança a cada produto consultado.</span><button className="button light small" disabled={stopRequested || !currentSync} onClick={()=>{stopSync.current=true;setStopRequested(true);toast.info("A atualização vai parar após o produto atual.");}}><Square size={13}/> {stopRequested ? "Parando após este produto..." : "Parar após este produto"}</button></div>}
        {syncResults.length > 0 && <details open={!syncing && syncFailed > 0}><summary>Ver resultado de cada produto</summary><ul>{syncResults.map(r=><li key={r.id} className={r.ok?"sync-ok":"sync-failed"}>{r.ok?<CheckCircle2 size={17}/>:<AlertCircle size={17}/>}<div><strong>{r.title}</strong><span>{r.message}</span></div></li>)}</ul></details>}
      </section>}
      {section === "firecrawl" ? <FirecrawlPanel configured={firecrawlConfigured} onConsulted={creditsChanged} busy={importBusy || syncing} onBusy={setImportBusy} onProduct={acceptProduct} onEdit={openEditor}/> : <>
      <section className="admin-products"><div className="section-heading"><h2>Seus produtos</h2><button className="button yellow small add-product-button" onClick={()=>setSection("firecrawl")}><Plus size={17}/> Novo produto</button><label className="admin-search"><Search size={18}/><input aria-label="Buscar no painel" value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar por nome ou link"/></label></div>
        <Tabs value={tab} onValueChange={setTab}><TabsList className="admin-tabs"><TabsTrigger value="all">Todos <span>{products.length}</span></TabsTrigger><TabsTrigger value="draft">Rascunhos <span>{products.length - published}</span></TabsTrigger><TabsTrigger value="active">Publicados <span>{published}</span></TabsTrigger></TabsList>
          <TabsContent value={tab}><div className="admin-product-list">{filtered.map((p, index) => <article key={p.id} className="admin-product"><div className="admin-product-image">{p.image_url ? <img src={p.image_url} alt={p.title || "Imagem do produto"} loading="lazy"/> : <><ImagePlus size={23}/><span>Sem foto</span></>}</div><div className="admin-product-details"><div className="admin-product-meta"><span className={"status-badge " + p.status}>{p.status === "active" ? "Publicado" : "Rascunho"}</span>{p.featured === 1 && <span className="featured-note">Destaque</span>}</div><h3>{p.title || "Produto aguardando identificação"}</h3><a href={p.affiliate_url} target="_blank" rel="noopener noreferrer sponsored">{p.affiliate_url}<ExternalLink size={12}/></a><span className="admin-product-category">{variants(p.variants_json).length>0 && `${variants(p.variants_json).length} opções de compra · `}{p.title ? p.category : "Adicione o nome e a foto do anúncio"}</span><div className="admin-price-row">{p.price_cents ? <><strong>{money(p.price_cents)}</strong>{discount(p)>0 && <span className="sale-chip">{discount(p)}% OFF</span>}{p.price_note && <small>{p.price_note}</small>}</> : <span>Preço ainda não consultado</span>}</div><span className="last-sync">{p.last_synced_at ? "Consultado em " + new Date(p.last_synced_at).toLocaleString("pt-BR",{timeZone:"America/Sao_Paulo",dateStyle:"short",timeStyle:"short"}) : "Use Atualizar para buscar preços e mais detalhes"}</span>{p.sync_error && <span className="sync-row-error">A última consulta falhou. Dados anteriores preservados.</span>}</div><div className="product-actions"><button className="button light small" onClick={()=>void updateProducts([p])} disabled={syncing || importBusy}><RefreshCw size={15}/> Atualizar</button><button className="button light small" onClick={() => openEditor(p)}><Pencil size={15}/>{p.title && p.image_url ? "Editar" : "Completar anúncio"}</button><button className="icon-button delete" onClick={() => setDeleting(p)} aria-label={"Excluir " + (p.title || "link " + (index + 1))}><Trash2 size={17}/></button></div></article>)}</div>{!filtered.length && <Empty><EmptyHeader><EmptyTitle>Nenhum produto nesta seleção</EmptyTitle><EmptyDescription>Adicione novos links ou ajuste a busca.</EmptyDescription></EmptyHeader></Empty>}</TabsContent>
        </Tabs>
      </section></>}<p className="admin-footnote">Os botões usam o link de afiliado da opção escolhida, quando cadastrado, ou o link principal do produto.</p>
    </main>
    <Dialog open={!!edit} onOpenChange={open => { if (!open && !busy) setEdit(null); }}><DialogContent className="product-editor" showCloseButton={false}><DialogHeader><DialogTitle>Editar produto</DialogTitle><DialogDescription>Informações, opções de compra e promoções da sua vitrine.</DialogDescription></DialogHeader><DialogClose className="editor-close" disabled={busy} aria-label="Fechar edição"><X size={20}/></DialogClose>{edit && <form onSubmit={saveProduct}>
      <div className="editor-fields"><label>Seu link de afiliado<input value={edit.affiliate_url} onChange={e => setEdit({ ...edit, affiliate_url: e.target.value })} type="url" required/><small>Este é o link usado no botão de compra.</small></label><label>Link completo do anúncio <span className="optional">opcional</span><input value={edit.source_url} onChange={e => setEdit({ ...edit, source_url: e.target.value })} placeholder="https://www.mercadolivre.com.br/..." type="url"/></label><button type="button" className="button light lookup-button" onClick={lookup} disabled={busy || syncing || importBusy}>{searching ? <LoaderCircle size={17} className="spin"/> : <Search size={17}/>} {searching ? "Consultando anúncio..." : "Pesquisar com Firecrawl"}</button><p className="field-help">Buscamos os dados disponíveis, incluindo fotos, preços, variações e características.</p>
      <div className="editor-divider"/>
      <div className="editor-image-block"><div className="editor-preview">{edit.image_url ? <img src={edit.image_url} alt="Prévia da imagem do produto"/> : <ImagePlus size={32}/>}</div><div><label className={"button light upload-label" + (uploading ? " disabled" : "")}>{uploading ? <LoaderCircle className="spin" size={17}/> : <ImagePlus size={17}/>} {uploading ? "Enviando..." : "Enviar foto"}<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => void upload(e.target.files?.[0])} disabled={busy} className="sr-only"/></label><small>JPG, PNG ou WebP · Até 4 MB</small><label className="image-url-label">Ou cole o link da imagem<input value={edit.image_url} onChange={e => setEdit({ ...edit, image_url: e.target.value })} placeholder="https://..."/></label></div></div>
      <label>Nome do produto<input value={edit.title} onChange={e => setEdit({ ...edit, title: e.target.value })} maxLength={200} placeholder="Nome completo do produto"/></label><label>Categoria<Select value={edit.category} onValueChange={category => setEdit({ ...edit, category })}><SelectTrigger className="editor-select"><SelectValue/></SelectTrigger><SelectContent>{CATEGORIES.map(c => <SelectItem value={c} key={c}>{c}</SelectItem>)}</SelectContent></Select></label><label>Descrição<textarea value={edit.description} onChange={e => setEdit({ ...edit, description: e.target.value })} maxLength={6000} rows={3} placeholder="Principais características verificadas no anúncio"/></label>
      <div className="editor-divider"/><h3 className="editor-subtitle">Preço e informações do anúncio</h3><div className="editor-two-columns"><label>Preço atual (R$)<input type="number" min="0.01" step="0.01" value={edit.price_cents == null ? "" : edit.price_cents/100} onChange={e=>setEdit({...edit,price_cents:e.target.value ? Math.round(Number(e.target.value)*100):null})}/></label><label>Preço anterior (R$)<input type="number" min="0.01" step="0.01" value={edit.original_price_cents == null ? "" : edit.original_price_cents/100} onChange={e=>setEdit({...edit,original_price_cents:e.target.value ? Math.round(Number(e.target.value)*100):null})}/></label></div><label>Condição do preço<input value={edit.price_note || ""} onChange={e=>setEdit({...edit,price_note:e.target.value})} placeholder="Ex.: preço no Pix" maxLength={300}/></label><div className="editor-two-columns"><label>Marca<input value={edit.brand || ""} onChange={e=>setEdit({...edit,brand:e.target.value})} maxLength={100}/></label><label>Tamanho ou medidas<input value={edit.size || ""} onChange={e=>setEdit({...edit,size:e.target.value})} maxLength={200}/></label><label>Unidades no kit<input type="number" min="1" step="1" value={edit.quantity ?? ""} onChange={e=>setEdit({...edit,quantity:e.target.value?Number(e.target.value):null})}/></label><label>Disponibilidade<Select value={edit.availability || "unknown"} onValueChange={v=>setEdit({...edit,availability:v as Product["availability"]})}><SelectTrigger className="editor-select"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="unknown">Não informada</SelectItem><SelectItem value="in_stock">Disponível</SelectItem><SelectItem value="out_of_stock">Indisponível</SelectItem></SelectContent></Select></label></div><label>Estoque informado no anúncio<input value={edit.stock_text || ""} onChange={e=>setEdit({...edit,stock_text:e.target.value})} placeholder="Ex.: mais de 5 disponíveis" maxLength={300}/></label><label>Variações — uma por linha<textarea rows={3} value={optionText} onChange={e=>setOptionText(e.target.value)} placeholder="Cor: preto, branco&#10;Voltagem: 127 V, 220 V"/></label><label>Características — uma por linha<textarea rows={4} value={specText} onChange={e=>setSpecText(e.target.value)} placeholder="Material: aço&#10;Modelo: ..."/></label>
      <ExtraProductFields product={edit} setProduct={setEdit}/><ProductOptionsEditor product={edit} setProduct={setEdit} onError={setError} onBusy={setUploading}/><OfferFields value={edit} onChange={patch=>setEdit(p=>p?{...p,...patch}:p)}/><p className="field-help">O prazo acima vale para o produto sem variação. Para opções com preços próprios, defina o prazo dentro de cada opção.</p><div className="editor-switch"><div><label htmlFor="featured-switch">Produto em destaque</label><p>Mostra este produto primeiro na seleção.</p></div><Switch id="featured-switch" checked={!!edit.featured} onCheckedChange={featured => setEdit({ ...edit, featured: featured ? 1 : 0 })}/></div><div className="editor-switch"><div><label htmlFor="publish-switch">Publicar na vitrine</label><p>Precisa de nome, foto e link de afiliado.</p></div><Switch id="publish-switch" checked={edit.status === "active"} onCheckedChange={active => setEdit({ ...edit, status: active ? "active" : "draft" })}/></div><div className="price-note"><Info size={17}/><span>Preços e disponibilidade podem mudar. O cliente confirma as condições no Mercado Livre.</span></div>{error && <p className="form-error" role="alert">{error}</p>}</div><div className="editor-footer"><button className="button light" type="button" onClick={() => setEdit(null)} disabled={busy}>Cancelar</button><button className="button dark" disabled={busy}>{saving ? <LoaderCircle className="spin" size={17}/> : <Check size={17}/>} {saving ? "Salvando..." : edit.status === "active" ? "Salvar e publicar" : "Salvar rascunho"}</button></div>
    </form>}</DialogContent></Dialog>
    <AlertDialog open={!!deleting} onOpenChange={open => { if (!open) setDeleting(null); }}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Excluir este produto?</AlertDialogTitle><AlertDialogDescription>O produto e seu link serão removidos da vitrine e do painel. Você pode cadastrar o link novamente depois.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="delete-confirm" onClick={e => { e.preventDefault(); void remove(); }}>Excluir produto</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
  </div>;
}
function ShieldIcon() { return <Check size={13}/>; }
