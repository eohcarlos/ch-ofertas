"use client";
import { useEffect, useState } from "react";
import { Flame, Link2, LoaderCircle, Check, Info, ArrowRight, PackageCheck, CircleAlert, RotateCw } from "lucide-react";
import { api } from "./api";
import { money, type Product } from "@/lib/catalog";
import { importQuality, GENERIC_DESCRIPTION } from "@/lib/import-quality";
import { toast } from "sonner";

export default function FirecrawlPanel({ busy, configured, onBusy, onProduct, onEdit, onConsulted }: { busy: boolean; configured: boolean; onBusy: (busy: boolean) => void; onProduct: (p: Product) => void; onEdit: (p: Product) => void; onConsulted: () => void }) {
  const [url, setUrl] = useState(""), [publish, setPublish] = useState(true), [importing, setImporting] = useState(false);
  const [result, setResult] = useState<Product | null>(null), [warnings, setWarnings] = useState<string[]>([]), [error, setError] = useState(""), [elapsed, setElapsed] = useState(0);
  const quality = result ? importQuality(result) : null;
  useEffect(() => {
    if (!importing) return;
    const started = Date.now();
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [importing]);
  async function importProduct(link: string) {
    setError(""); setWarnings([]); setImporting(true); setElapsed(0); onBusy(true);
    try {
      const response = await api("/firecrawl/import", "POST", { url: link.trim(), publish });
      setResult(response.product); setWarnings(response.warnings || []); onProduct(response.product); setUrl("");
      const incomplete = importQuality(response.product).partial;
      toast.success(response.refreshed ? "Informações do produto atualizadas." : response.product.status === "active" ? "Produto publicado." : "Produto salvo como rascunho.", { description: incomplete ? "Confira os campos pendentes no resultado da importação." : "Confira as informações importadas abaixo." });
    } catch (e) { setError((e as Error).message); }
    finally { setImporting(false); onBusy(false); onConsulted(); }
  }
  return <section className="firecrawl-panel" aria-label="Importação Firecrawl">
    <div className="firecrawl-intro"><span className="firecrawl-mark"><Flame size={22}/>Firecrawl</span><span className="integration-mode">{configured ? "Conta conectada" : "Modo sem chave · limitado"}</span>
      <h2>Do anúncio<br/>para sua vitrine<span>.</span></h2><p>Adicione o link. A importação consulta a oferta selecionada, lê a ficha do produto e organiza as informações disponíveis.</p>
      <div className="import-features"><span><Check size={14}/>Descrição e ficha técnica</span><span><Check size={14}/>Preços e condições</span><span><Check size={14}/>Galeria de até 16 fotos</span><span><Check size={14}/>Voltagem, cor e tamanho</span><span><Check size={14}/>Preço de cada opção</span><span><Check size={14}/>Disponibilidade e promoções</span></div>
    </div>
    <div className="firecrawl-form-card"><form onSubmit={e => { e.preventDefault(); void importProduct(url); }}>
      <label htmlFor="firecrawl-url">Link de afiliado do Mercado Livre</label><input id="firecrawl-url" type="url" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://meli.la/seu-link" required disabled={busy} maxLength={2048}/>
      <span className="field-help">O link de compra original será preservado. Links já cadastrados atualizam o produto existente.</span>
      <label className="publish-check"><input type="checkbox" checked={publish} onChange={e => setPublish(e.target.checked)} disabled={busy}/><span>Publicar novos produtos após importar</span></label>
      <button className="button yellow" disabled={busy || !url.trim()}>{importing ? <LoaderCircle size={19} className="spin"/> : <Link2 size={19}/>} {importing ? "Consultando o anúncio…" : publish ? "Importar e publicar produto" : "Importar como rascunho"}</button>
      {importing && <div className="import-running" role="status"><div><strong>Buscando as informações</strong><span>{elapsed}s</span></div><progress aria-label="Consulta em andamento"/><p>{elapsed < 30 ? "Lendo a oferta, a descrição e as fotos disponíveis." : "A consulta continua. Alguns anúncios e opções demoram mais para responder."}</p></div>}
      {error && <p className="form-error" role="alert">{error}</p>}
    </form><div className="import-explainer"><Info size={18}/><p>O resultado mostra o que foi encontrado. Campos bloqueados ou não informados no anúncio ficam sinalizados para revisão. Preços de opções e prazos de promoção só entram quando confirmados na fonte.</p></div></div>
    {result && quality && <div className="import-result">
      <div className="import-result-heading"><PackageCheck size={20}/><h3>{quality.partial ? "Importado · revisar informações" : "Produto importado"}</h3><span className={"status-badge " + result.status}>{result.status === "active" ? "Publicado" : "Rascunho"}</span></div>
      <div className="import-result-body"><img src={result.image_url} alt={result.title}/><div><span className="eyebrow">{result.category}</span><h3>{result.title}</h3>{result.description && result.description !== GENERIC_DESCRIPTION && <p>{result.description}</p>}<strong className="import-price">{result.price_cents ? money(result.price_cents) : "Preço não informado"}</strong>{result.price_note && <small>{result.price_note}</small>}
        <div className="result-facts"><span>{quality.photos} {quality.photos === 1 ? "foto" : "fotos"}</span><span>{quality.specifications} características</span><span>{quality.options} opções identificadas</span>{result.offer_ends_at && <span>Prazo da oferta identificado</span>}</div>
        <button className="button dark small" onClick={() => onEdit(result)}>Revisar produto<ArrowRight size={16}/></button>
      </div></div>
      <div className="import-quality"><div className="import-quality-heading"><strong>Informações identificadas</strong><span>{quality.checks.filter(c => c.found).length} de {quality.checks.length} campos principais</span></div><div className="quality-checks">{quality.checks.map(check => <div key={check.label} className={check.found ? "found" : "missing"}>{check.found ? <Check size={14}/> : <CircleAlert size={14}/>}<span>{check.label}{!check.found && " · pendente"}</span></div>)}</div></div>
      {warnings.length > 0 && <ul className="import-warnings">{warnings.map(w => <li key={w}>{w}</li>)}</ul>}
      <button className="button light small" style={{ marginTop: 18 }} onClick={() => void importProduct(result.affiliate_url)} disabled={busy}><RotateCw size={15}/>Buscar informações novamente</button>
    </div>}
  </section>;
}
