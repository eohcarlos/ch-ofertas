"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Coins, KeyRound, RefreshCw, LoaderCircle, Check, ExternalLink, Link2, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { api, ApiError } from "./api";
import type { FirecrawlConnection, FirecrawlSettings, FirecrawlUsage } from "@/lib/firecrawl-account";

const count = (value: number) => value.toLocaleString("pt-BR", { maximumFractionDigits: 2 });
const date = (value: string) => new Date(value).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" });
export default function FirecrawlAccount({ revision, busy, onConfigured }: { revision: number; busy: boolean; onConfigured: (value: boolean) => void }) {
  const [settings, setSettings] = useState<FirecrawlSettings | null>(null);
  const [usage, setUsage] = useState<FirecrawlUsage | null>(null), [loading, setLoading] = useState(false), [error, setError] = useState("");
  const [key, setKey] = useState(""), [saving, setSaving] = useState(false), [open, setOpen] = useState(false);
  const [connection, setConnection] = useState<FirecrawlConnection | null>(null), [polling, setPolling] = useState(false), [connecting, setConnecting] = useState(false), [connectionError, setConnectionError] = useState("");
  const [variation, setVariation] = useState<number | null>(null);
  const previousUsage = useRef<FirecrawlUsage | null>(null), requestId = useRef(0), checking = useRef(false);
  const applyUsage = useCallback((value: FirecrawlUsage | null, reset = false) => {
    const previous = previousUsage.current;
    setVariation(!reset && previous && value && previous.billingPeriodStart === value.billingPeriodStart ? value.remainingCredits - previous.remainingCredits : null);
    previousUsage.current = value; setUsage(value);
  }, []);
  const refreshUsage = useCallback(async () => {
    const id = ++requestId.current; setLoading(true);
    try {
      const r = await api("/firecrawl/usage"); if (id !== requestId.current) return;
      setSettings(r.settings); onConfigured(r.settings.hasKey); applyUsage(r.usage); setError("");
    } catch (e) { if (id === requestId.current) setError((e as Error).message); }
    finally { if (id === requestId.current) setLoading(false); }
  }, [applyUsage, onConfigured]);
  useEffect(() => {
    let active = true;
    api("/firecrawl/settings").then(r => { if (active) { setSettings(r.settings); onConfigured(r.settings.hasKey); setOpen(!r.settings.hasKey); } }).catch(e => { if (active) setError(e.message); });
    api("/firecrawl/connect").then(r => { if (active && r.connection) { setConnection(r.connection); setPolling(true); setOpen(true); } }).catch(() => {});
    return () => { active = false; requestId.current++; };
  }, [onConfigured]);
  useEffect(() => { void refreshUsage(); }, [revision, refreshUsage]);
  async function saveKey(e: React.FormEvent) {
    e.preventDefault(); setSaving(true); setConnectionError(""); requestId.current++;
    try {
      const r = await api("/firecrawl/settings", "POST", { api_key: key.trim() });
      setSettings(r.settings); onConfigured(r.settings.hasKey); applyUsage(r.usage, true); setKey(""); setConnection(null); setPolling(false); setError("");
      toast.success("Chave validada e salva. Saldo conectado à sua conta.");
    } catch (e) { setConnectionError((e as Error).message); }
    finally { setSaving(false); setLoading(false); }
  }
  async function removeKey() {
    setSaving(true); requestId.current++;
    try { const r = await api("/firecrawl/settings", "DELETE"); setSettings(r.settings); onConfigured(r.settings.hasKey); applyUsage(r.usage, true); setConnection(null); setPolling(false); setError(""); toast.success("Chave removida."); }
    catch (e) { setConnectionError((e as Error).message); } finally { setSaving(false); setLoading(false); }
  }
  async function connect() {
    setConnecting(true); setConnectionError("");
    try { const r = await api("/firecrawl/connect", "POST", {}); setConnection(r.connection); setPolling(true); }
    catch (e) { setConnectionError((e as Error).message); } finally { setConnecting(false); }
  }
  const checkConnection = useCallback(async () => {
    if (checking.current || !connection) return;
    if (connection.expiresAt <= Date.now()) { setPolling(false); setConnection(null); setConnectionError("A autorização expirou. Clique em Conectar Firecrawl para tentar novamente."); return; }
    checking.current = true;
    try {
      const r = await api("/firecrawl/connect/status", "POST", {});
      if (r.connectionStatus === "complete") {
        requestId.current++; setLoading(false); setSettings(r.settings); onConfigured(r.settings.hasKey); applyUsage(r.usage, true); setConnection(null); setPolling(false); setError(""); setConnectionError("");
        toast.success("Firecrawl conectado. Seus créditos já estão disponíveis na loja.");
      }
    } catch (e) { setConnectionError((e as Error).message); setPolling(false); if (e instanceof ApiError && e.status === 410) setConnection(null); }
    finally { checking.current = false; }
  }, [connection, onConfigured, applyUsage]);
  useEffect(() => {
    if (!connection || !polling) return;
    const check = () => { if (document.visibilityState === "visible" && !busy && !saving) void checkConnection(); };
    const timer = window.setInterval(check, 4000); window.addEventListener("focus", check);
    return () => { window.clearInterval(timer); window.removeEventListener("focus", check); };
  }, [connection, polling, checkConnection, busy, saving]);
  async function cancel() {
    setPolling(false); setConnecting(true);
    try { await api("/firecrawl/connect", "DELETE"); setConnection(null); setConnectionError(""); }
    catch (e) { setConnectionError((e as Error).message); } finally { setConnecting(false); }
  }
  return <section className="firecrawl-account" id="firecrawl-account" aria-label="Chave e créditos do Firecrawl">
    <div className="credit-summary">
      <div className="credit-label"><Coins size={21}/><div><strong>Créditos Firecrawl</strong><span>{settings?.hasKey ? "Saldo da sua conta" : settings ? "Conecte sua conta para acompanhar" : "Conferindo conexão..."}</span></div></div>
      <div className="credit-balance" aria-live="polite"><strong>{usage ? count(usage.remainingCredits) : "—"}</strong><span>{usage ? "disponíveis" : "Saldo não conectado"}</span></div>
      {usage && <div className="credit-plan"><span>{usage.planCredits != null ? count(usage.planCredits) + " créditos no plano" : "Saldo informado pelo Firecrawl"}</span>{usage.billingPeriodEnd && <small>Período até {date(usage.billingPeriodEnd)}</small>}</div>}
      <button className="button light small" onClick={() => void refreshUsage()} disabled={loading || saving || !settings?.hasKey} aria-label="Atualizar saldo do Firecrawl">{loading ? <LoaderCircle size={16} className="spin"/> : <RefreshCw size={16}/>} Atualizar saldo</button>
    </div>
    {usage && <p className="credit-caption">{variation !== null && variation !== 0 && <strong>{variation < 0 ? count(-variation) + " crédito(s) a menos" : "+" + count(variation) + " crédito(s)"} desde a consulta anterior. </strong>}Saldo atualizado às {new Date(usage.checkedAt).toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit", second: "2-digit" })}. {busy ? "Acompanhando o processamento dos produtos." : "Atualiza após cada consulta de produto."} O saldo também reflete outros usos da mesma conta.</p>}
    {error && <p className="form-error credit-error" role="alert">{error}{usage ? " Exibindo o último saldo confirmado." : ""}</p>}
    <button className="account-toggle" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="firecrawl-account-settings"><KeyRound size={17}/><strong>Chave e créditos</strong><span>{settings?.hasKey ? "Chave configurada" : "Configurar conexão"}</span><ChevronDown size={16} className={open ? "is-open" : ""}/></button>
    {open && <div className="account-settings" id="firecrawl-account-settings">
      <p>Conecte sua conta Firecrawl para importar produtos e acompanhar seus créditos. A chave fica protegida no servidor.</p>
      {connection ? <div className="firecrawl-connect-pending"><strong>Autorize a conexão no Firecrawl</strong><p>Abra o link abaixo, entre na sua conta e toque em Autorizar. Depois volte para este painel: a chave será salva automaticamente.</p><div className="account-actions"><a className="button dark small" href={connection.url} target="_blank" rel="noopener noreferrer">Autorizar no Firecrawl <ExternalLink size={15}/></a><button className="button light small" onClick={() => { setConnectionError(""); void checkConnection(); }} disabled={saving || busy}>Verificar conexão</button><button className="text-button" onClick={() => void cancel()} disabled={connecting || saving || busy}>Cancelar</button></div>{polling && <span className="connection-wait" role="status"><LoaderCircle size={14} className="spin"/> Aguardando sua autorização</span>}</div> : <button className="button dark small" onClick={() => void connect()} disabled={connecting || saving || busy}>{connecting ? <LoaderCircle size={17} className="spin"/> : <Link2 size={17}/>} {settings?.hasKey ? "Conectar outra conta" : "Conectar Firecrawl"}</button>}
      <form className="manual-key-form" onSubmit={saveKey}><label htmlFor="firecrawl-key">Ou cole sua chave de API</label><div className="key-input-row"><input id="firecrawl-key" type="password" autoComplete="off" spellCheck={false} placeholder={settings?.hasKey ? "Cole uma chave para substituir a atual" : "fc-..."} value={key} onChange={e => setKey(e.target.value)} maxLength={203} disabled={saving || busy}/><button className="button light" disabled={saving || busy || !key.trim()}>{saving ? <LoaderCircle size={17} className="spin"/> : <Check size={17}/>} Validar e salvar</button></div></form>
      {connectionError && <p className="form-error" role="alert">{connectionError}</p>}
      <div className="settings-links"><a href="https://www.firecrawl.dev/app/api-keys" target="_blank" rel="noopener noreferrer">Abrir minhas chaves <ExternalLink size={13}/></a>{settings?.mode === "saved" && <button onClick={() => void removeKey()} disabled={saving || busy}>Remover chave salva</button>}</div>
    </div>}
  </section>;
}
