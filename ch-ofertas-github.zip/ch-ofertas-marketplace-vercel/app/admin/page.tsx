import { adminCatalog } from "@/lib/store";
import AdminLogin from "./login";
import AdminPanel from "./panel";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Gerenciar vitrine | CH Ofertas", robots: { index: false, follow: false } };

export default async function AdminPage() {
  try {
    const products = await adminCatalog();
    return products ? <AdminPanel initialProducts={products}/> : <AdminLogin/>;
  } catch {
    return <main className="access-state"><h1>O painel está indisponível</h1><p>Não foi possível carregar seus produtos. Tente novamente em instantes.</p><a className="button dark" href="/admin">Tentar novamente</a></main>;
  }
}
