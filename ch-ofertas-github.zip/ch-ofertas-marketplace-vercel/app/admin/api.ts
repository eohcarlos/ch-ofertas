import type { Product } from "@/lib/catalog";
import type { FirecrawlSettings, FirecrawlUsage, FirecrawlConnection } from "@/lib/firecrawl-account";
export type ApiResult = { error?: string; code?: string; products: Product[]; product: Product; added: number; metadata: Partial<Product>; image_url: string; ok?: boolean; warnings?: string[]; duplicate?: boolean; refreshed?: boolean; settings: FirecrawlSettings; usage: FirecrawlUsage | null; connection: FirecrawlConnection | null; connectionStatus?: "pending" | "complete"; retryAfter?: number | null };
export class ApiError extends Error { constructor(message: string, public status: number, public retryAfter: number | null = null) { super(message); } }
export async function api(path: string, method = "GET", body?: unknown) {
  const res = await fetch("/api/admin" + path, { method, cache: "no-store", headers: body instanceof FormData ? undefined : { "Content-Type": "application/json" }, body: body === undefined ? undefined : body instanceof FormData ? body : JSON.stringify(body) });
  let result: ApiResult; try { result = await res.json(); } catch { throw new ApiError("A conexão foi interrompida. Recarregue o painel para conferir o resultado antes de tentar novamente.", res.status); }
  if (res.status === 401 && result.code === "AUTH_REQUIRED") { window.location.replace("/admin"); throw new ApiError(result.error || "Entre novamente.",401); }
  if (!res.ok) throw new ApiError(result.error || "Não foi possível concluir.", res.status, result.retryAfter || null);
  return result;
}
