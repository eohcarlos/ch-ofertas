"use client";
import { useMemo, useState } from "react";
import { Search, Tag, ShoppingBag, SlidersHorizontal, ShieldCheck, X, PackageOpen, ArrowUpRight, Info, ChevronRight, Images, Grid2X2, Truck, Check, Zap } from "lucide-react";
import { Brand } from "./brand";
import HeroCarousel from "./hero-carousel";
import { ShopClock, useShopTime, ProductPrice, FlashOffer } from "./product-offer";
import { variants, variantLabel, variantProduct, lowestPrice, displayPrice, productDetails, DETAIL_FIELDS, type ProductVariant } from "@/lib/commerce";
import { CATEGORIES, money, discount, attributes, gallery, type Product } from "@/lib/catalog";
import { GENERIC_DESCRIPTION } from "@/lib/import-quality";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription, EmptyMedia } from "@/components/ui/empty";

function VariantChoices({ rows, selected, onSelect }: { rows: ProductVariant[]; selected?: ProductVariant; onSelect: (id: string) => void }) {
  const names = [...new Set(rows.flatMap(v => v.attributes.map(a => a.name)))];
  function choose(name: string, value: string) {
    const matching = rows.filter(v => v.attributes.some(a => a.name === name && a.value === value));
    const candidate = matching.find(v => !selected || selected.attributes.filter(a => a.name !== name).every(a => v.attributes.some(x => x.name === a.name && x.value === a.value))) || matching.find(v => v.availability !== "out_of_stock") || matching[0];
    if (candidate) onSelect(candidate.id);
  }
  return <div className="detail-choices">{names.map(name => <fieldset key={name}>
    <legend>{name}{selected && <strong>: {selected.attributes.find(a => a.name === name)?.value}</strong>}</legend>
    <div>{[...new Set(rows.flatMap(v => v.attributes.filter(a => a.name === name).map(a => a.value)))].map(value => {
      const unavailable = rows.filter(v => v.attributes.some(a => a.name === name && a.value === value)).every(v => v.availability === "out_of_stock");
      return <button type="button" key={value} aria-pressed={selected?.attributes.some(a => a.name === name && a.value === value) || false} className={unavailable ? "option-unavailable" : ""} onClick={() => choose(name, value)}>{value}{unavailable && <small>Indisponível</small>}</button>;
    })}</div>
  </fieldset>)}{selected && <p className="selected-combination" role="status">Selecionado: <strong>{variantLabel(selected)}</strong></p>}</div>;
}

function ProductPhoto({ src, alt, className = "", eager = false }: { src: string; alt: string; className?: string; eager?: boolean }) {
  const [failed, setFailed] = useState(false);
  return failed ? <span className="image-error"><PackageOpen size={28}/>Foto indisponível</span> : <img src={src} alt={alt} className={className} width="500" height="500" loading={eager ? "eager" : "lazy"} onError={() => setFailed(true)}/>;
}

export function ProductCard({ product }: { product: Product }) {
  const rows = useMemo(() => variants(product.variants_json), [product.variants_json]);
  const [chosen, setChosen] = useState(rows.length === 1 ? rows[0].id : "");
  const [details, setDetails] = useState(false), [selectedImage, setSelectedImage] = useState("");
  const now = useShopTime() ?? Date.now(), selected = rows.find(v => v.id === chosen);
  const cheapest = [...rows].filter(v => v.availability !== "out_of_stock").sort((a, b) => (displayPrice(a, now) ?? Infinity) - (displayPrice(b, now) ?? Infinity))[0] || rows[0];
  const displayed = selected ? variantProduct(product, selected) : rows.length && cheapest ? variantProduct(product, cheapest) : product;
  const picture = selected?.image_url || product.image_url;
  const pictures = [...new Set([picture, product.image_url, ...gallery(product.gallery_json || "[]")])];
  const shownImage = pictures.includes(selectedImage) ? selectedImage : picture;
  const sale = discount(displayed, now), specs = attributes(product.specifications_json), facts = productDetails(product.details_json);
  const hasDescription = product.description && product.description !== GENERIC_DESCRIPTION;
  const specificationRows = [...(selected?.attributes || []), ...Object.entries(facts).map(([k, value]) => ({ name: DETAIL_FIELDS[k as keyof typeof DETAIL_FIELDS], value: value! })), ...specs].filter((s, i, all) => all.findIndex(a => normalize(a.name) === normalize(s.name)) === i);
  const target = selected?.affiliate_url || product.affiliate_url;
  const buyLabel = displayed.availability === "out_of_stock" ? "Conferir disponibilidade" : "Ver no Mercado Livre";
  const openDetails = () => { setSelectedImage(picture); setDetails(true); };
  const choose = (id: string) => { setChosen(id); setSelectedImage(rows.find(v => v.id === id)?.image_url || product.image_url); };
  return <>
    <article className="product-card">
      <button type="button" className="product-image" onClick={openDetails} aria-label={"Ver fotos e detalhes de " + product.title}>
        {sale > 0 && (!rows.length || selected) ? <span className="product-badge sale">{sale}% OFF</span> : product.featured === 1 && <span className="product-badge editorial-badge">SELEÇÃO CH</span>}
        <ProductPhoto key={picture} src={picture} alt={product.title}/>
        {pictures.length > 1 && <span className="photo-count"><Images size={13}/>{pictures.length}</span>}
      </button>
      <div className="product-info">
        <span className="card-brand">{product.brand || product.category}</span>
        <h3><button type="button" onClick={openDetails}>{product.title}</button></h3>
        <div className="card-price-area" aria-live="polite" aria-atomic="true"><ProductPrice product={displayed} from={!!rows.length && !selected}/></div>
        {(!rows.length || selected) && <FlashOffer product={displayed}/>}
        {rows.length > 0 && <label className="card-option-picker">{rows.length} {rows.length === 1 ? "opção disponível" : "opções para escolher"}<select value={selected?.id || ""} onChange={e => choose(e.target.value)}>
          <option value="">Escolher {rows[0].attributes.map(a => a.name.toLowerCase()).join(" / ")}</option>
          {rows.map(v => <option key={v.id} value={v.id}>{variantLabel(v)} · {v.availability === "out_of_stock" ? "Indisponível" : displayPrice(v, now) ? money(displayPrice(v, now)!) : "Consultar preço"}</option>)}
        </select></label>}
        <div className="product-quick-facts">{displayed.quantity != null && <span>{displayed.quantity} un. no kit</span>}{!rows.length && facts.voltage && <span>{facts.voltage}</span>}{!rows.length && facts.capacity && <span>{facts.capacity}</span>}</div>
        {displayed.availability === "out_of_stock" && <span className="card-unavailable">Indisponível na última consulta</span>}
        <div className="product-bottom">
          {rows.length && !selected ? <button className="button yellow" onClick={openDetails}>Escolher opção <ChevronRight size={16}/></button> : <a className="button yellow" href={target} target="_blank" rel="sponsored noopener noreferrer">{buyLabel}<ArrowUpRight size={16}/></a>}
          <button className="product-details-button" onClick={openDetails}>Fotos e detalhes <ChevronRight size={14}/></button>
        </div>
      </div>
    </article>
    <Dialog open={details} onOpenChange={setDetails}>
      <DialogContent className="product-detail-dialog marketplace-detail">
        <DialogHeader><span className="detail-breadcrumb">CH Ofertas <ChevronRight size={12}/>{product.category}</span><DialogTitle>{product.title}</DialogTitle><DialogDescription>Veja as características e escolha a opção do produto.</DialogDescription></DialogHeader>
        <div className="product-detail-layout">
          <div className="detail-gallery"><div className="detail-photo-stage"><ProductPhoto key={shownImage} src={shownImage} alt={product.title} className="detail-main-image" eager/></div>
            {pictures.length > 1 && <div className="detail-thumbnails" aria-label="Fotos do produto">{pictures.map((src, i) => <button key={src} type="button" onClick={() => setSelectedImage(src)} className={shownImage === src ? "active" : ""} aria-pressed={shownImage === src} aria-label={"Ver foto " + (i + 1)}><img src={src} alt={"Foto " + (i + 1)} loading="lazy"/></button>)}</div>}
          </div>
          <div className="detail-info">
            <div className="detail-purchase-heading"><span>{product.brand || "Produto selecionado"}</span>{facts.condition && <span>{facts.condition}</span>}</div>
            <div aria-live="polite" aria-atomic="true"><ProductPrice product={displayed} from={!!rows.length && !selected}/></div>
            {(!rows.length || selected) && <FlashOffer product={displayed}/>}
            {rows.length > 0 && <VariantChoices rows={rows} selected={selected} onSelect={choose}/>}
            <dl className="detail-attributes">{product.brand && <div><dt>Marca</dt><dd>{product.brand}</dd></div>}{displayed.size && <div><dt>Medidas</dt><dd>{displayed.size}</dd></div>}{displayed.quantity != null && <div><dt>Unidades no kit</dt><dd>{displayed.quantity}</dd></div>}{displayed.stock_text && <div><dt>Disponibilidade</dt><dd>{displayed.stock_text}</dd></div>}{selected?.sku && <div><dt>Referência da opção</dt><dd>{selected.sku}</dd></div>}{!rows.length && attributes(product.options_json).map((x, i) => <div key={i}><dt>{x.name}</dt><dd>{x.value}</dd></div>)}</dl>
            {rows.length && !selected ? <p className="choose-option-hint">Selecione uma opção para conferir seu preço.</p> : <a className="button yellow" href={target} target="_blank" rel="sponsored noopener noreferrer"><ShoppingBag size={18}/>{buyLabel}<ArrowUpRight size={17}/></a>}
            <div className="purchase-facts"><p><Truck size={18}/><span><strong>Entrega e frete</strong>{facts.shipping || "Calcule para seu endereço no anúncio."}</span></p><p><ShieldCheck size={18}/><span><strong>Compra no Mercado Livre</strong>Pagamento e acompanhamento por lá.</span></p></div>
            <p className="detail-disclaimer"><Info size={15}/>{selected && !selected.affiliate_url ? "Confirme " + variantLabel(selected) + " no anúncio. Seu acesso será pelo link principal do produto." : "Preço, estoque e condições podem mudar. Confira o valor final no anúncio."}</p>
          </div>
        </div>
        {hasDescription && <section className="detail-description"><h3>Sobre este produto</h3><p>{product.description}</p></section>}
        {specificationRows.length > 0 && <section className="detail-specs"><h3>Ficha técnica <span>{specificationRows.length} características</span></h3><dl>{specificationRows.map((x, i) => <div key={i}><dt>{x.name}</dt><dd>{x.value}</dd></div>)}</dl></section>}
        {!hasDescription && !specificationRows.length && <p className="detail-missing"><Info size={17}/>A ficha completa deste produto está no anúncio. Confira antes de comprar.</p>}
      </DialogContent>
    </Dialog>
  </>;
}

const normalize = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
function StorefrontContent({ products, unavailable }: { products: Product[]; unavailable: boolean }) {
  const clock = useShopTime(), now = clock ?? Date.now();
  const [onlyOffers, setOnlyOffers] = useState(false), [filtersOpen, setFiltersOpen] = useState(false);
  const [query, setQuery] = useState(""), [category, setCategory] = useState("Todos"), [sort, setSort] = useState("featured"), [priceRange, setPriceRange] = useState("all");
  const availableCategories = CATEGORIES.filter(c => products.some(p => p.category === c));
  const offers = useMemo(() => new Set(products.filter(p => variants(p.variants_json).length ? variants(p.variants_json).some(v => discount(variantProduct(p, v), now) > 0) : discount(p, now) > 0).map(p => p.id)), [products, now]);
  const visible = useMemo(() => {
    const q = normalize(query).trim().split(/\s+/).filter(Boolean);
    return products.filter(p => {
      const price = lowestPrice(p, now), text = normalize([p.title, p.description, p.category, p.brand, p.details_json].join(" "));
      const inRange = priceRange === "all" || (priceRange === "100" ? price <= 10000 : priceRange === "300" ? price > 10000 && price <= 30000 : Number.isFinite(price) && price > 30000);
      return (!onlyOffers || offers.has(p.id)) && (category === "Todos" || p.category === category) && q.every(word => text.includes(word)) && inRange;
    }).sort((a, b) => sort === "price" ? lowestPrice(a, now) - lowestPrice(b, now) : sort === "price-desc" ? (Number.isFinite(lowestPrice(b, now)) ? lowestPrice(b, now) : -1) - (Number.isFinite(lowestPrice(a, now)) ? lowestPrice(a, now) : -1) : sort === "newest" ? b.created_at.localeCompare(a.created_at) : b.featured - a.featured || a.position - b.position);
  }, [products, query, category, sort, onlyOffers, offers, now, priceRange]);
  const hasFilters = query || category !== "Todos" || onlyOffers || priceRange !== "all";
  function reset() { setQuery(""); setCategory("Todos"); setOnlyOffers(false); setPriceRange("all"); }
  function explore(value: string) { setCategory(value); document.getElementById("achados")?.scrollIntoView({ behavior: "smooth" }); }
  return <div className="storefront marketplace">
    <div className="announcement"><span>CH OFERTAS</span><span>Uma boa escolha começa aqui.</span><span>Compra direto no Mercado Livre <ArrowUpRight size={12}/></span></div>
    <header className="store-header"><div className="container header-inner"><Brand/>
      <form className="search-box" role="search" onSubmit={e => { e.preventDefault(); document.getElementById("achados")?.scrollIntoView({ behavior: "smooth" }); }}><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar produtos, marcas e muito mais" aria-label="Buscar produtos"/>{query && <button type="button" onClick={() => setQuery("")} aria-label="Limpar busca"><X size={16}/></button>}<button type="submit" className="search-submit" aria-label="Pesquisar"><Search size={21}/></button></form>
      <a href="#como-funciona" className="header-help"><ShieldCheck size={24}/><span>Escolha por aqui.<strong>Compre no Mercado Livre.</strong></span></a>
    </div><nav className="container shop-nav" aria-label="Navegação da loja"><a href="#categorias"><Grid2X2 size={15}/>Categorias</a><button onClick={() => { setOnlyOffers(true); explore("Todos"); }}><Tag size={15}/>Ofertas</button><a href="#achados">Todos os produtos</a><a href="#como-funciona">Como comprar</a><span>Seleção independente, feita para você</span></nav></header>
    <main className="container">
      <HeroCarousel/>
      <div className="shopping-benefits"><div><Tag size={24}/><span><strong>Encontre seu próximo achado</strong>Casa, tecnologia e muito mais.</span></div><div><SlidersHorizontal size={24}/><span><strong>Escolha a opção certa</strong>Compare os valores disponíveis.</span></div><div><ShoppingBag size={24}/><span><strong>Finalize no Mercado Livre</strong>Confira frete e condições por lá.</span></div></div>
      {availableCategories.length > 0 && <section className="category-showcase" id="categorias"><div className="market-section-title"><h2>O que você está procurando?</h2><a href="#achados">Ver todos <ChevronRight size={15}/></a></div><div className="category-tiles">{availableCategories.map(c => { const product = products.find(p => p.category === c)!; return <button key={c} onClick={() => explore(c)} aria-pressed={category === c}><span className="category-photo"><img src={product.image_url} alt="" width="120" height="120" loading="lazy"/></span><strong>{c}</strong><span>{products.filter(p => p.category === c).length} produtos <ChevronRight size={13}/></span></button>; })}</div></section>}
      <section id="achados" className="catalog-section">
        <div className="market-section-title catalog-title"><div><span className="eyebrow">SELEÇÃO CH OFERTAS</span><h2>{query ? "Resultados da sua busca" : onlyOffers ? "Ofertas para aproveitar" : category === "Todos" ? "Achados que valem a sua atenção" : category}</h2><p>{visible.length} {visible.length === 1 ? "produto encontrado" : "produtos encontrados"}</p></div><div className="catalog-toolbar"><button className="mobile-filters" aria-expanded={filtersOpen} aria-controls="catalog-filters" onClick={() => setFiltersOpen(!filtersOpen)}><SlidersHorizontal size={17}/>Filtrar</button><Select value={sort} onValueChange={setSort}><SelectTrigger className="sort-select" aria-label="Ordenar produtos"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="featured">Em destaque</SelectItem><SelectItem value="newest">Mais recentes</SelectItem><SelectItem value="price">Menor preço</SelectItem><SelectItem value="price-desc">Maior preço</SelectItem></SelectContent></Select></div></div>
        <div className="catalog-layout">
          <aside id="catalog-filters" className={"catalog-sidebar" + (filtersOpen ? " is-open" : "")} aria-label="Filtrar produtos"><div className="filters-heading"><h3>Filtros</h3>{hasFilters && <button onClick={reset}>Limpar</button>}</div>
            <button className={"offers-toggle" + (onlyOffers ? " active" : "")} aria-pressed={onlyOffers} onClick={() => setOnlyOffers(!onlyOffers)}><Tag size={16}/><span>Somente ofertas</span><b>{offers.size}</b>{onlyOffers && <Check size={14}/>}</button>
            <fieldset className="filter-category-list"><legend>Categorias</legend>{["Todos", ...availableCategories].map(c => <button key={c} onClick={() => setCategory(c)} aria-pressed={category === c}><span>{c}</span><small>{c === "Todos" ? products.length : products.filter(p => p.category === c).length}</small></button>)}</fieldset>
            <fieldset className="filter-prices"><legend>Faixa de preço</legend>{[["all", "Todos os preços"], ["100", "Até R$ 100"], ["300", "R$ 100 a R$ 300"], ["above", "Acima de R$ 300"]].map(([value, label]) => <label key={value}><input type="radio" name="price-range" value={value} checked={priceRange === value} onChange={() => setPriceRange(value)}/>{label}</label>)}</fieldset>
            <p className="filter-note"><Info size={15}/>O preço pode variar conforme a opção escolhida.</p>
          </aside>
          <div className="catalog-results">
            {hasFilters && <div className="active-filters">{query && <button onClick={() => setQuery("")}>“{query}”<X size={12}/></button>}{category !== "Todos" && <button onClick={() => setCategory("Todos")}>{category}<X size={12}/></button>}{onlyOffers && <button onClick={() => setOnlyOffers(false)}>Ofertas<X size={12}/></button>}{priceRange !== "all" && <button onClick={() => setPriceRange("all")}>Faixa de preço<X size={12}/></button>}</div>}
            {offers.size > 0 && !hasFilters && <button className="catalog-offer-band" onClick={() => setOnlyOffers(true)}><span className="offer-band-icon"><Zap size={21}/></span><span><strong>Tem oferta na seleção</strong><small>{offers.size} produtos com desconto confirmado na última consulta.</small></span><span>Conferir <ChevronRight size={16}/></span></button>}
            {visible.length > 0 ? <div className="product-grid">{visible.map(p => <ProductCard key={p.id} product={p}/>)}</div> : <Empty className="catalog-empty"><EmptyHeader><EmptyMedia className="empty-tag"><PackageOpen size={34}/></EmptyMedia><EmptyTitle>{unavailable ? "Não foi possível carregar os produtos" : products.length ? "Nenhum produto encontrado" : "Nossa seleção está chegando"}</EmptyTitle><EmptyDescription>{unavailable ? "Tente recarregar a página em alguns instantes." : products.length ? "Altere a busca ou limpe os filtros para explorar a seleção." : "Volte em breve para conferir os próximos achados."}</EmptyDescription></EmptyHeader>{products.length > 0 && <button className="button light" onClick={reset}>Limpar filtros</button>}{unavailable && <a className="button light" href="/">Tentar novamente</a>}</Empty>}
          </div>
        </div>
      </section>
      <section id="como-funciona" className="how-section"><div className="how-heading"><span className="eyebrow">DA ESCOLHA À COMPRA</span><h2>Seu achado está aqui.<br/><span>A compra acontece lá.</span></h2></div><div className="how-steps"><article><span>01</span><h3>Encontre o produto</h3><p>Explore fotos, características e opções da nossa seleção.</p></article><article><span>02</span><h3>Confira o anúncio</h3><p>Veja o preço final, o frete para seu endereço e a disponibilidade.</p></article><article><span>03</span><h3>Compre no Mercado Livre</h3><p>Finalize o pagamento e acompanhe sua entrega na plataforma.</p></article></div></section>
    </main>
    <footer className="store-footer"><div className="container"><div className="footer-top"><Brand inverse/><span>Boas escolhas para todos os seus dias.</span></div><div className="footer-info"><p>A CH Ofertas é uma vitrine independente e não é a loja oficial do Mercado Livre. Ao comprar pelos nossos links de afiliado, podemos receber uma comissão. Preços, estoque, frete e condições são os informados no anúncio no momento da compra.</p></div><div className="footer-bottom"><span>© {new Date().getFullYear()} CH Ofertas</span><a href="#como-funciona">Como funciona nossa seleção</a></div></div></footer>
  </div>;
}
export default function Storefront(props: { products: Product[]; unavailable: boolean; initialNow?: number }) { return <ShopClock initialNow={props.initialNow}><StorefrontContent {...props}/></ShopClock>; }
