export function Brand({ inverse = false }: { inverse?: boolean }) {
  return <a href="/" className={"brand brand-graphic" + (inverse ? " inverse" : "")} aria-label="CH Ofertas, início"><img src="/brand/ch-ofertas-logo-v2.webp" alt="CH Ofertas" width="600" height="200" fetchPriority="high"/></a>;
}
