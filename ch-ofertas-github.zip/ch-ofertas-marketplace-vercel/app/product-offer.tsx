"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { Clock3, Zap } from "lucide-react";
import { discount, money, type Product } from "@/lib/catalog";
import { displayPrice, promotionState } from "@/lib/commerce";

const ClockContext = createContext<number | null>(null);
export function ShopClock({children,initialNow}:{children:React.ReactNode;initialNow?:number}) {
  const [now,setNow]=useState<number|null>(initialNow??null);
  useEffect(()=>{
    let alive=true, epoch=initialNow??Date.now(), tick=performance.now();
    const update=()=>{if(alive)setNow(epoch+performance.now()-tick);};
    const sync=async()=>{
      const start=performance.now();
      try {const response=await fetch('/api/time',{cache:'no-store',signal:AbortSignal.timeout(6000)});const value=await response.json() as {now?:number};if(alive && typeof value.now==='number'){epoch=value.now+(performance.now()-start)/2;tick=performance.now();}}
      catch {} update();
    };
    void sync();const interval=setInterval(update,1000);
    const visible=()=>{if(document.visibilityState==='visible')void sync();};
    document.addEventListener('visibilitychange',visible);
    return ()=>{alive=false;clearInterval(interval);document.removeEventListener('visibilitychange',visible);};
  },[initialNow]);
  return <ClockContext.Provider value={now}>{children}</ClockContext.Provider>;
}
export function useShopTime(){return useContext(ClockContext);}
export function FlashOffer({product}:{product:Product}) {
  const clock=useShopTime(),now=clock??Date.now(),state=promotionState(product,now);
  if(!product.offer_ends_at || product.availability==='out_of_stock' || !product.price_cents)return null;
  if(state==='expired')return <p className="offer-ended"><Clock3 size={14}/> Oferta encerrada. Consulte o valor atual.</p>;
  if(state==='scheduled')return <p className="offer-scheduled"><Clock3 size={14}/> Oferta a partir de {new Date(product.offer_starts_at!).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo',dateStyle:'short',timeStyle:'short'})}</p>;
  if(state!=='active')return null;
  const seconds=Math.max(0,Math.ceil((Date.parse(product.offer_ends_at)-now)/1000)),days=Math.floor(seconds/86400),hours=Math.floor(seconds/3600)%24,minutes=Math.floor(seconds/60)%60,rest=seconds%60;
  const deadline=new Date(product.offer_ends_at).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo',dateStyle:'short',timeStyle:'short'});
  return <div className="flash-offer"><div><Zap size={14}/><strong>Oferta relâmpago</strong></div><span role="timer" aria-live="off" aria-label={'Tempo restante da oferta. Termina em '+deadline+' de Brasília'}>{clock===null?'Calculando prazo…':<>{days>0 && <b>{days}d</b>}<b>{String(hours).padStart(2,'0')}</b><i>:</i><b>{String(minutes).padStart(2,'0')}</b><i>:</i><b>{String(rest).padStart(2,'0')}</b></>}</span><small>Até {deadline} · Brasília</small></div>;
}
export function ProductPrice({product,from=false}:{product:Product;from?:boolean}) {
  const now=useShopTime()??Date.now(),price=displayPrice(product,now),sale=discount(product,now);
  if(!price)return <span className="price-hint">{promotionState(product,now)==='expired'?'Consulte o preço atualizado':promotionState(product,now)==='scheduled'?'Preço promocional ainda não vigente':'Confira o preço desta opção no anúncio'}</span>;
  return <div className="product-pricing">{from && <span className="price-from">A partir de</span>}{sale>0 && <div className="previous-price"><s>{money(product.original_price_cents!)}</s><span>{sale}% OFF</span></div>}<strong>{money(price)}</strong>{product.price_note && <span className="price-condition">{product.price_note}</span>}<small>{product.price_checked_at || product.last_synced_at ? 'Valor conferido em '+new Date(product.price_checked_at||product.last_synced_at).toLocaleDateString('pt-BR',{timeZone:'America/Sao_Paulo'}):'Confirme o valor no anúncio'}</small></div>;
}
