"use client";

import { useEffect, useState } from "react";

const slides = [
  { id: "selection", label: "SELEÇÃO CH OFERTAS", title: "Menos procura.", accent: "Mais achados.", description: "Boas escolhas para sua casa, seu trabalho e todos os seus dias.", footer: "Casa · Tecnologia · Conforto", image: "" },
  { id: "home", label: "CASA E COZINHA", title: "Sua casa,", accent: "do seu jeito.", description: "Praticidade nos pequenos detalhes. Mais conforto para a sua rotina.", footer: "Descubra os produtos da nossa seleção", image: "/banners/casa-v1.webp" },
  { id: "work", label: "TECNOLOGIA E CONFORTO", title: "Seu espaço.", accent: "Novas possibilidades.", description: "Achados para trabalhar, estudar e aproveitar melhor cada momento.", footer: "Encontre sua próxima boa escolha", image: "/banners/escritorio-v1.webp" },
];

export default function HeroCarousel() {
  const [index, setIndex] = useState(0), [animate, setAnimate] = useState(true);
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (!document.hidden) { setAnimate(true); setIndex(value => value + 1); }
    }, 5000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    if (index !== slides.length) return;
    const timer = window.setTimeout(() => { setAnimate(false); setIndex(0); }, 750);
    return () => window.clearTimeout(timer);
  }, [index]);

  return <section className="hero-carousel" aria-label="Destaques da CH Ofertas" aria-roledescription="carrossel">
    <h1 className="sr-only">CH Ofertas: achados para sua casa, tecnologia e conforto</h1>
    <div className={"hero-track" + (animate ? " is-animated" : "")} style={{ transform: `translateX(-${index * 100}%)` }}>
      {[...slides, slides[0]].map((slide, position) => <article key={`${slide.id}-${position}`} className={`hero-slide hero-slide-${slide.id}`} aria-hidden={position !== index} aria-label={`${position % slides.length + 1} de ${slides.length}`}>
        {slide.image && <img className="hero-scene" src={slide.image} alt="" width="1672" height="941" loading="eager" decoding="async"/>}
        <div className="banner-copy"><span className="banner-kicker"><span/>{slide.label}</span><h2>{slide.title}<br/><em>{slide.accent}</em></h2><p>{slide.description}</p><span className="banner-footnote">{slide.footer}</span></div>
        {slide.id === "selection" && <div className="banner-products banner-brand" aria-hidden="true"><span className="banner-products-label">ESCOLHA BEM. VIVA MELHOR.</span><img className="banner-brand-logo" src="/brand/ch-ofertas-logo-v2.webp" alt="" width="2172" height="724"/><span className="banner-brand-tagline">Sua próxima<br/><strong>boa escolha.</strong></span><span className="banner-products-caption">Curadoria independente · Mercado Livre</span></div>}
      </article>)}
    </div>
  </section>;
}
