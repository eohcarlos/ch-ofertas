import Storefront from "./storefront";
import { readProducts } from "@/lib/store";
import type { Product } from "@/lib/catalog";
export const dynamic = "force-dynamic";
export default async function Home() {
  let products: Product[] = [], unavailable = false;
  try { products = await readProducts(); } catch (e) { console.error("Catalog unavailable", e); unavailable = true; }
  return <Storefront products={products} unavailable={unavailable} initialNow={Date.now()} />;
}
