import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CH Ofertas | Seus próximos achados",
  description: "Uma seleção de produtos para o seu dia a dia. Descubra achados na CH Ofertas e confira os preços diretamente no Mercado Livre.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
