import { backendFetch } from "@/lib/backend";

export const runtime = "nodejs";
export async function GET(_request: Request, context: { params: Promise<{ key: string }> }) {
  const { key } = await context.params;
  if (!/^[a-f0-9-]+\.(png|jpg|webp)$/.test(key)) return new Response("Imagem não encontrada.", { status: 404 });
  try {
    const response = await backendFetch("/api/images/" + key);
    if (!response.ok) return new Response("Imagem não encontrada.", { status: response.status === 404 ? 404 : 502 });
    const type = response.headers.get("content-type") || "";
    if (!/^image\/(jpeg|png|webp)$/.test(type)) return new Response("Imagem indisponível.", { status: 502 });
    return new Response(response.body, { headers: { "Content-Type": type, "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" } });
  } catch { return new Response("Imagem temporariamente indisponível.", { status: 502 }); }
}
