import { BACKEND_ORIGIN, adminCookie, backendFetch } from "@/lib/backend";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 300;
const json = (error: string, status: number) => Response.json({ error }, { status, headers: { "Cache-Control": "private, no-store" } });

async function handler(request: Request) {
  const url = new URL(request.url);
  const write = request.method !== "GET";
  // Enforce same-origin at this boundary before translating to the backend
  // origin. A valid server-side session is still required by the backend.
  if (write && request.headers.get("origin") !== url.origin) return json("Origem não permitida.", 403);
  const headers = new Headers({ Accept: "application/json" });
  const cookie = adminCookie(request.headers);
  if (cookie) headers.set("cookie", cookie);
  const type = request.headers.get("content-type");
  if (type) headers.set("content-type", type);
  if (write) headers.set("origin", BACKEND_ORIGIN);
  try {
    if (Number(request.headers.get("content-length") || 0) > 4_300_000) return json("Conteúdo muito grande.", 413);
    const body = write ? await request.arrayBuffer() : undefined;
    if (body && body.byteLength > 4_300_000) return json("Conteúdo muito grande.", 413);
    const response = await backendFetch(url.pathname + url.search, { method: request.method, headers, body });
    if (!response.headers.get("content-type")?.includes("application/json")) return json("Serviço temporariamente indisponível. Tente novamente.", 502);
    const resultHeaders = new Headers({ "Content-Type": "application/json", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" });
    const session = response.headers.get("set-cookie");
    if (session?.startsWith("__Host-ch-admin=")) resultHeaders.set("set-cookie", session);
    const retry = response.headers.get("retry-after");
    if (retry) resultHeaders.set("retry-after", retry);
    return new Response(response.body, { status: response.status, headers: resultHeaders });
  } catch {
    return json("A conexão foi interrompida. Recarregue o painel para conferir o resultado antes de tentar novamente.", 502);
  }
}

export const GET = handler;
export const POST = handler;
export const PATCH = handler;
export const DELETE = handler;
