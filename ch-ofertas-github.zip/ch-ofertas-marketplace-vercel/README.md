# CH Ofertas on Vercel

Next.js storefront and password-protected admin UI. The existing catalog, Firecrawl integration, image storage and server-side sessions remain in the Sites backend. No credentials are included in this export.

Generate from the source repository with `node scripts/export-vercel.mjs /absolute/empty/directory`. Updates can be deployed through Vercel CLI or a Git integration.
